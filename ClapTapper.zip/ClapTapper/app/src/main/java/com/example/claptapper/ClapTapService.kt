package com.example.claptapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Performs the actual screen tap. Must be enabled by the user in
 * Settings > Accessibility. It ignores all accessibility events.
 */
class ClapTapService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClapTapService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    /** Tap at a position given as a percentage (0-100) of the screen. */
    fun tapPercent(xPercent: Int, yPercent: Int) {
        val dm = resources.displayMetrics
        val x = dm.widthPixels * xPercent / 100f
        val y = dm.heightPixels * yPercent / 100f
        val path = Path().apply { moveTo(x, y) }
        val stroke = GestureDescription.StrokeDescription(path, 0, 50)
        val gesture = GestureDescription.Builder().addStroke(stroke).build()
        dispatchGesture(gesture, null, null)
    }
}
