package com.example.claptapper

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent

/**
 * Performs the actual screen tap. Must be enabled by the user in
 * Settings > Accessibility. It ignores all accessibility events.
 */
class ClapTapService : AccessibilityService() {

    companion object {
        @Volatile
        var instance: ClapTapService? = null
        private const val HOLD_SEGMENT_MS = 1000L
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    private val main = Handler(Looper.getMainLooper())
    private var holdStroke: GestureDescription.StrokeDescription? = null
    private var holdPath: Path? = null
    @Volatile var holding = false
        private set

    private fun pathFor(xPercent: Int, yPercent: Int): Path {
        val dm = resources.displayMetrics
        return Path().apply {
            moveTo(dm.widthPixels * xPercent / 100f, dm.heightPixels * yPercent / 100f)
        }
    }

    /** Instant tap (1 ms touch, starts immediately) at a percentage of the screen. */
    fun tapPercent(xPercent: Int, yPercent: Int) {
        if (holding) releaseHold()
        val stroke = GestureDescription.StrokeDescription(pathFor(xPercent, yPercent), 0, 1)
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), null, null)
    }

    /** Clap once: press and keep the finger down. Clap again: let go. */
    fun toggleHold(xPercent: Int, yPercent: Int) {
        if (holding) releaseHold() else startHold(xPercent, yPercent)
    }

    private fun startHold(xPercent: Int, yPercent: Int) {
        val path = pathFor(xPercent, yPercent)
        val stroke = GestureDescription.StrokeDescription(path, 0, HOLD_SEGMENT_MS, true)
        holdPath = path
        holdStroke = stroke
        holding = true
        dispatch(stroke)
    }

    private fun dispatch(stroke: GestureDescription.StrokeDescription) {
        val cb = object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) {
                // Chain the next segment so the finger never lifts.
                if (holding && holdStroke === stroke) {
                    val next = stroke.continueStroke(holdPath!!, 0, HOLD_SEGMENT_MS, true)
                    holdStroke = next
                    dispatch(next)
                }
            }

            override fun onCancelled(g: GestureDescription?) {
                if (holdStroke === stroke) {
                    holding = false
                    holdStroke = null
                }
            }
        }
        dispatchGesture(GestureDescription.Builder().addStroke(stroke).build(), cb, main)
    }

    fun releaseHold() {
        val stroke = holdStroke
        val path = holdPath
        holding = false
        holdStroke = null
        if (stroke != null && path != null) {
            val up = stroke.continueStroke(path, 0, 1, false)
            dispatchGesture(GestureDescription.Builder().addStroke(up).build(), null, null)
        }
    }
}
