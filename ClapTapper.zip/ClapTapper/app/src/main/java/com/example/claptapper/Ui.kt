package com.example.claptapper

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

object C {
    val BG = 0xFF0B0E14.toInt()
    val CARD = 0xFF151A23.toInt()
    val CARD2 = 0xFF1E2430.toInt()
    val STROKE = 0xFF252C3A.toInt()
    val STROKE2 = 0xFF39425A.toInt()
    val TEXT = 0xFFEAEFF7.toInt()
    val MUTED = 0xFF8B95A7.toInt()
    val ACC1 = 0xFF5B8CFF.toInt()
    val ACC2 = 0xFF9A6BFF.toInt()
    val GREEN = 0xFF3DDC97.toInt()
    val WARN = 0xFFFFB454.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

fun Context.shape(color: Int, radiusDp: Float, strokeColor: Int = 0, strokeDp: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = dpf(radiusDp)
        if (strokeDp > 0) setStroke(dp(strokeDp), strokeColor)
    }

fun Context.label(text: String, sizeSp: Float, color: Int, bold: Boolean = false): TextView =
    TextView(this).apply {
        this.text = text
        textSize = sizeSp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

/** The big power button. Glows with the live sound level. */
class OrbView(ctx: Context) : View(ctx) {
    var on = false
    var level = 0f
    private var flashAmt = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    fun flash() {
        flashAmt = 1f
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f * 0.58f
        val l = sqrt(level.coerceIn(0f, 1f))

        paint.shader = null
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.dpf(2f)
        if (on) {
            for (i in 1..3) {
                val a = (110f * l / i).toInt().coerceIn(0, 255)
                paint.color = Color.argb(a, 124, 140, 255)
                canvas.drawCircle(cx, cy, r * (1f + 0.10f * i) + r * 0.30f * l * i, paint)
            }
        }
        if (flashAmt > 0f) {
            paint.strokeWidth = context.dpf(3f)
            paint.color = Color.argb((220 * flashAmt).toInt().coerceIn(0, 255), 255, 255, 255)
            canvas.drawCircle(cx, cy, r * (1f + (1f - flashAmt) * 0.9f), paint)
            flashAmt = max(0f, flashAmt - 0.07f)
        }

        paint.style = Paint.Style.FILL
        if (on) {
            paint.shader = LinearGradient(
                cx - r, cy - r, cx + r, cy + r, C.ACC1, C.ACC2, Shader.TileMode.CLAMP
            )
        } else {
            paint.color = C.CARD2
        }
        canvas.drawCircle(cx, cy, r, paint)
        paint.shader = null

        if (!on) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = context.dpf(2f)
            paint.color = C.STROKE2
            canvas.drawCircle(cx, cy, r, paint)
        }

        // power icon
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.dpf(5f)
        paint.strokeCap = Paint.Cap.ROUND
        paint.color = if (on) Color.WHITE else C.MUTED
        val ir = r * 0.36f
        val acy = cy + ir * 0.1f
        box.set(cx - ir, acy - ir, cx + ir, acy + ir)
        canvas.drawArc(box, 305f, 290f, false, paint)
        canvas.drawLine(cx, cy - ir * 1.1f, cx, cy - ir * 0.15f, paint)
    }
}

/** Live sound level bar with a marker for the trigger threshold. */
class MeterView(ctx: Context) : View(ctx) {
    var level = 0f
    var threshold = 0.2f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val box = RectF()

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val barH = context.dpf(14f)
        val top = (height - barH) / 2f

        paint.style = Paint.Style.FILL
        paint.color = C.CARD2
        box.set(0f, top, w, top + barH)
        canvas.drawRoundRect(box, barH / 2f, barH / 2f, paint)

        if (level > 0.003f) {
            val right = max(barH, w * sqrt(level.coerceIn(0f, 1f)))
            paint.color = if (level >= threshold) C.GREEN else C.ACC1
            box.set(0f, top, right, top + barH)
            canvas.drawRoundRect(box, barH / 2f, barH / 2f, paint)
        }

        val x = w * sqrt(threshold.coerceIn(0f, 1f))
        paint.color = Color.WHITE
        paint.strokeWidth = context.dpf(3f)
        paint.strokeCap = Paint.Cap.ROUND
        canvas.drawLine(x, top - context.dpf(4f), x, top + barH + context.dpf(4f), paint)
    }
}

/** Mini phone screen: drag to choose where the tap lands. */
class PhonePickerView(ctx: Context) : View(ctx) {
    var xPct = 50
    var yPct = 50
    var onPick: ((Int, Int) -> Unit)? = null
    private var pulseAmt = 0f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val body = RectF()
    private val screen = RectF()

    fun pulse() {
        pulseAmt = 1f
        invalidate()
    }

    override fun onMeasure(widthSpec: Int, heightSpec: Int) {
        val w = MeasureSpec.getSize(widthSpec)
        setMeasuredDimension(w, (w * 2.05f).toInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val s = context.dpf(2f)
        body.set(s, s, w - s, h - s)
        val inset = context.dpf(8f)
        screen.set(body.left + inset, body.top + inset * 1.8f, body.right - inset, body.bottom - inset * 1.8f)
    }

    override fun onDraw(c: Canvas) {
        val r20 = context.dpf(20f)
        paint.style = Paint.Style.FILL
        paint.color = C.CARD2
        c.drawRoundRect(body, r20, r20, paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.dpf(2f)
        paint.color = C.STROKE2
        c.drawRoundRect(body, r20, r20, paint)

        paint.style = Paint.Style.FILL
        paint.color = C.BG
        c.drawRoundRect(screen, context.dpf(12f), context.dpf(12f), paint)

        // faint grid
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.dpf(1f)
        paint.color = 0x14FFFFFF
        for (i in 1..3) {
            val vx = screen.left + screen.width() * i / 4f
            val hy = screen.top + screen.height() * i / 4f
            c.drawLine(vx, screen.top, vx, screen.bottom, paint)
            c.drawLine(screen.left, hy, screen.right, hy, paint)
        }

        val px = screen.left + screen.width() * xPct / 100f
        val py = screen.top + screen.height() * yPct / 100f

        paint.color = Color.argb(110, 124, 140, 255)
        c.drawLine(px, screen.top, px, screen.bottom, paint)
        c.drawLine(screen.left, py, screen.right, py, paint)

        if (pulseAmt > 0f) {
            paint.strokeWidth = context.dpf(2.5f)
            paint.color = Color.argb((230 * pulseAmt).toInt().coerceIn(0, 255), 61, 220, 151)
            c.drawCircle(px, py, context.dpf(12f) + (1f - pulseAmt) * context.dpf(34f), paint)
            pulseAmt = max(0f, pulseAmt - 0.08f)
            postInvalidateOnAnimation()
        }

        paint.style = Paint.Style.FILL
        paint.color = C.ACC1
        c.drawCircle(px, py, context.dpf(8f), paint)
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = context.dpf(2f)
        paint.color = Color.WHITE
        c.drawCircle(px, py, context.dpf(8f), paint)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                val fx = ((e.x - screen.left) / screen.width()).coerceIn(0f, 1f)
                val fy = ((e.y - screen.top) / screen.height()).coerceIn(0f, 1f)
                xPct = (fx * 100f).toInt()
                yPct = (fy * 100f).toInt()
                invalidate()
                onPick?.invoke(xPct, yPct)
                return true
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Pill-style option picker. */
class Segmented(
    ctx: Context,
    options: List<String>,
    initial: Int,
    private val onSelect: (Int) -> Unit
) : LinearLayout(ctx) {

    private val tabs = mutableListOf<TextView>()
    var selected = initial
        private set

    init {
        orientation = HORIZONTAL
        background = ctx.shape(C.CARD2, 12f)
        setPadding(ctx.dp(4), ctx.dp(4), ctx.dp(4), ctx.dp(4))
        options.forEachIndexed { i, name ->
            val t = ctx.label(name, 14f, C.MUTED, true)
            t.gravity = Gravity.CENTER
            t.setPadding(0, ctx.dp(10), 0, ctx.dp(10))
            t.setOnClickListener { select(i, true) }
            tabs.add(t)
            addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        }
        select(initial, false)
    }

    private fun select(i: Int, notify: Boolean) {
        selected = i
        tabs.forEachIndexed { idx, t ->
            if (idx == i) {
                t.background = context.shape(C.ACC1, 9f)
                t.setTextColor(Color.WHITE)
            } else {
                t.background = null
                t.setTextColor(C.MUTED)
            }
        }
        if (notify) onSelect(i)
    }
}

/** A setup step with a status mark and a fix button. */
class SetupRow(
    ctx: Context,
    title: String,
    desc: String,
    action: String,
    onClick: () -> Unit
) : LinearLayout(ctx) {

    private val mark = ctx.label("!", 18f, C.WARN, true)
    private val button = ctx.label(action, 13f, Color.WHITE, true)

    init {
        orientation = HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(0, ctx.dp(8), 0, ctx.dp(8))

        mark.gravity = Gravity.CENTER
        addView(mark, LinearLayout.LayoutParams(ctx.dp(28), WRAP))

        val col = LinearLayout(ctx)
        col.orientation = VERTICAL
        col.addView(ctx.label(title, 15f, C.TEXT, true))
        col.addView(ctx.label(desc, 12f, C.MUTED))
        addView(col, LinearLayout.LayoutParams(0, WRAP, 1f))

        button.background = ctx.shape(C.ACC1, 10f)
        button.setPadding(ctx.dp(14), ctx.dp(8), ctx.dp(14), ctx.dp(8))
        button.setOnClickListener { onClick() }
        addView(button)
    }

    fun setDone(done: Boolean) {
        mark.text = if (done) "✓" else "!"
        mark.setTextColor(if (done) C.GREEN else C.WARN)
        button.visibility = if (done) View.GONE else View.VISIBLE
    }
}
