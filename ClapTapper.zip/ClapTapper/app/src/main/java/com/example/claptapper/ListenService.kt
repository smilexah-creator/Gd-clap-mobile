package com.example.claptapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import kotlin.math.abs

/**
 * Foreground service that listens to the microphone and asks
 * ClapTapService to tap when a loud sound is detected.
 */
class ListenService : Service() {

    companion object {
        @Volatile
        var running = false
        const val PREFS = "cfg"
        private const val CHANNEL = "listen"
    }

    @Volatile
    private var active = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_STICKY
        startInForeground()
        running = true
        active = true
        worker = Thread { listenLoop() }.also { it.start() }
        return START_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Clap Tapper is listening")
            .setContentText("A loud sound will tap the screen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun listenLoop() {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(
            rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val buffer = ShortArray(maxOf(minBuf, 1024) / 2)
        val recorder = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                buffer.size * 2
            )
        } catch (e: SecurityException) {
            stopSelf(); return
        }
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            recorder.release(); stopSelf(); return
        }

        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        var lastTap = 0L
        recorder.startRecording()
        try {
            while (active) {
                val n = recorder.read(buffer, 0, buffer.size)
                if (n <= 0) continue
                var peak = 0
                for (i in 0 until n) peak = maxOf(peak, abs(buffer[i].toInt()))

                // Sensitivity 0..100 -> threshold 0.50..0.03 of full scale
                val sensitivity = prefs.getInt("sensitivity", 60)
                val threshold = (0.5f - sensitivity / 100f * 0.47f) * 32768f
                val cooldown = prefs.getInt("cooldown", 500)
                val now = System.currentTimeMillis()

                if (peak > threshold && now - lastTap > cooldown) {
                    lastTap = now
                    ClapTapService.instance?.tapPercent(
                        prefs.getInt("x", 50), prefs.getInt("y", 50)
                    )
                }
            }
        } finally {
            recorder.stop()
            recorder.release()
        }
    }

    override fun onDestroy() {
        active = false
        running = false
        worker?.join(500)
        super.onDestroy()
    }
}
