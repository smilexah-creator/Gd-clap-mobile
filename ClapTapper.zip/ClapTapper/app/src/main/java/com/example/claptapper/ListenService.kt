package com.example.claptapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin
import kotlin.math.sqrt

private const val BANDS = 8
private val BAND_HZ = intArrayOf(100, 300, 600, 1000, 1600, 2500, 4000, 6000, 8000)
private const val LEARN_MS = 12000L

/** Splits a 512-sample frame into 8 frequency bands (FFT). */
private class Spectrum(private val n: Int, rate: Int) {
    private val re = FloatArray(n)
    private val im = FloatArray(n)
    private val window = FloatArray(n) { (0.5 - 0.5 * cos(2.0 * PI * it / (n - 1))).toFloat() }
    private val cosT = FloatArray(n / 2) { cos(-2.0 * PI * it / n).toFloat() }
    private val sinT = FloatArray(n / 2) { sin(-2.0 * PI * it / n).toFloat() }
    private val rev = IntArray(n)
    private val edges = IntArray(BANDS + 1) {
        (BAND_HZ[it] * n / rate.toFloat()).toInt().coerceIn(1, n / 2)
    }

    init {
        val bits = Integer.numberOfTrailingZeros(n)
        for (i in 0 until n) rev[i] = Integer.reverse(i) ushr (32 - bits)
    }

    fun bands(x: ShortArray, out: FloatArray) {
        for (i in 0 until n) {
            re[i] = x[i] / 32768f * window[i]
            im[i] = 0f
        }
        for (i in 0 until n) {
            val j = rev[i]
            if (j > i) {
                val t = re[i]; re[i] = re[j]; re[j] = t
            }
        }
        var size = 2
        while (size <= n) {
            val half = size / 2
            val step = n / size
            var i = 0
            while (i < n) {
                for (k in 0 until half) {
                    val wr = cosT[k * step]
                    val wi = sinT[k * step]
                    val a = i + k
                    val b = a + half
                    val tr = wr * re[b] - wi * im[b]
                    val ti = wr * im[b] + wi * re[b]
                    re[b] = re[a] - tr
                    im[b] = im[a] - ti
                    re[a] += tr
                    im[a] += ti
                }
                i += size
            }
            size *= 2
        }
        for (b in 0 until BANDS) {
            val lo = edges[b]
            val hi = edges[b + 1]
            var s = 0f
            for (k in lo until hi) s += re[k] * re[k] + im[k] * im[k]
            out[b] = sqrt(s / max(1, hi - lo)) / n * 4f
        }
    }
}

/**
 * Foreground service that listens to the microphone and asks
 * ClapTapService to tap when a clap is detected.
 *
 * Phone sound filter (pref "filter"):
 *   0 Off    - plain microphone, simple loudness + sharp-onset test
 *   1 Smart  - echo cancellation + frequency analysis. A clap must stand out
 *              from the background (and from the learned game music)
 *              in several frequency bands at once.
 *   2 Strict - Smart, and detection pauses while the phone plays audio
 */
class ListenService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var level = 0f
        @Volatile var paused = false
        @Volatile var taps = 0
        @Volatile var tapEvent = 0L
        @Volatile var learning = false
        @Volatile var learnLeft = 0
        @Volatile private var learnRequested = false

        const val PREFS = "cfg"
        private const val CHANNEL = "listen"
        private const val ACTION_STOP = "com.example.claptapper.STOP"
        private const val ACTION_RELOAD = "com.example.claptapper.RELOAD"
        private const val ACTION_LEARN = "com.example.claptapper.LEARN"

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, ListenService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ListenService::class.java))
        }

        /** Re-create the recorder (needed when the filter option changes). */
        fun reload(ctx: Context) {
            if (running) {
                ctx.startService(Intent(ctx, ListenService::class.java).setAction(ACTION_RELOAD))
            }
        }

        /** Record the background (game) sound for a few seconds and remember it. */
        fun learn(ctx: Context) {
            if (running) {
                ctx.startService(Intent(ctx, ListenService::class.java).setAction(ACTION_LEARN))
            }
        }
    }

    @Volatile private var active = false
    @Volatile private var restartRecorder = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                restartRecorder = true
                return START_NOT_STICKY
            }
            ACTION_LEARN -> {
                learnRequested = true
                return START_NOT_STICKY
            }
        }
        startInForeground()
        if (!running) {
            running = true
            active = true
            taps = 0
            worker = Thread { listenLoop() }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Clap Tapper is listening")
            .setContentText("A clap will tap the screen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Stop", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun loadProfile(prefs: SharedPreferences): FloatArray? {
        val s = prefs.getString("profile", null) ?: return null
        val parts = s.split(",")
        if (parts.size != BANDS) return null
        return try {
            FloatArray(BANDS) { parts[it].toFloat() }
        } catch (e: Exception) {
            null
        }
    }

    private fun buzz() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(250, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (e: Exception) {
        }
    }

    private fun listenLoop() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val am = getSystemService(AudioManager::class.java)
        val rate = 16000
        val frame = 512 // ~32 ms
        val buffer = ShortArray(frame)
        val spectrum = Spectrum(frame, rate)

        val e = FloatArray(BANDS)
        val baseline = FloatArray(BANDS)
        val calMax = FloatArray(BANDS)
        var profile = loadProfile(prefs)
        var calStart = 0L

        var lastTap = 0L
        var prevPeak = 0f
        var prevHf = 0f
        var prevHf2 = 0f
        var lastPhoneAudio = 0L
        var lastGateCheck = 0L

        while (active) {
            restartRecorder = false
            val filter = prefs.getInt("filter", 1)
            val source = if (filter == 0) {
                MediaRecorder.AudioSource.MIC
            } else {
                MediaRecorder.AudioSource.VOICE_COMMUNICATION
            }
            val minBuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val recorder = try {
                AudioRecord(
                    source, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 8)
                )
            } catch (ex: Exception) {
                stopSelf(); return
            }
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release(); stopSelf(); return
            }

            var aec: AcousticEchoCanceler? = null
            if (filter != 0 && AcousticEchoCanceler.isAvailable()) {
                try {
                    aec = AcousticEchoCanceler.create(recorder.audioSessionId)
                    aec?.enabled = true
                } catch (ex: Exception) {
                    aec = null
                }
            }

            recorder.startRecording()
            try {
                while (active && !restartRecorder) {
                    val n = recorder.read(buffer, 0, frame)
                    if (n < frame) continue

                    var peakInt = 0
                    for (i in 0 until frame) peakInt = maxOf(peakInt, abs(buffer[i].toInt()))
                    val p = peakInt / 32768f
                    level = p

                    spectrum.bands(buffer, e)
                    val hf = (e[3] + e[4] + e[5] + e[6] + e[7]) / 5f

                    val sens = prefs.getInt("sensitivity", 60)
                    val threshold = 0.5f - sens / 100f * 0.47f
                    val mode = prefs.getInt("mode", 0)
                    val cooldown = prefs.getInt("cooldown_ms", 0)
                    val now = SystemClock.elapsedRealtime()

                    // --- Learning the background / game sound -----------------
                    if (learnRequested) {
                        learnRequested = false
                        learning = true
                        calStart = now
                        calMax.fill(0f)
                    }
                    if (learning) {
                        for (i in 0 until BANDS) calMax[i] = max(calMax[i], e[i])
                        val left = ((LEARN_MS - (now - calStart)) / 1000 + 1).toInt()
                        learnLeft = max(left, 0)
                        if (now - calStart >= LEARN_MS) {
                            profile = calMax.copyOf()
                            prefs.edit().putString("profile", profile!!.joinToString(",")).apply()
                            learning = false
                            buzz()
                        }
                    }

                    // --- Strict filter: stay quiet while the phone plays sound -
                    var gated = false
                    if (filter == 2) {
                        if (now - lastGateCheck > 150) {
                            lastGateCheck = now
                            val playing = am.isMusicActive ||
                                am.activePlaybackConfigurations.isNotEmpty()
                            if (playing) lastPhoneAudio = now
                        }
                        gated = now - lastPhoneAudio < 700
                    }
                    paused = gated

                    // --- Decide ------------------------------------------------
                    var trigger = false
                    if (!learning && p > threshold) {
                        if (filter == 0) {
                            trigger = if (mode == 0) p > prevPeak * 2.2f + 0.01f else true
                        } else {
                            // How far each band rises above the background/game sound.
                            val margin = 1.3f + (1f - sens / 100f) * 3.2f
                            var over = 0
                            for (i in 1 until BANDS) {
                                val ref = max(profile?.get(i) ?: 0f, baseline[i] * 2f) + 2e-4f
                                if (e[i] > ref * margin) over++
                            }
                            // A clap lifts many bands at once; bass beats or a single
                            // tone do not.
                            trigger = over >= (if (mode == 0) 3 else 2)
                            if (trigger && mode == 0) {
                                // and it has to be a sharp onset in the upper bands
                                trigger = hf > minOf(prevHf, prevHf2) * 1.8f + 0.0005f
                            }
                        }
                    }

                    val holdMode = prefs.getInt("tap_style", 0) == 1
                    // Hold mode toggles press/release, so one clap's echo must not
                    // flip it twice - keep a short guard there only.
                    val wait = if (holdMode) max(cooldown, 250) else cooldown
                    if (trigger && !gated && now - lastTap >= wait) {
                        lastTap = now
                        val svc = ClapTapService.instance
                        val tx = prefs.getInt("x", 50)
                        val ty = prefs.getInt("y", 50)
                        if (holdMode) svc?.toggleHold(tx, ty) else svc?.tapPercent(tx, ty)
                        taps++
                        tapEvent = now
                    }

                    // Background level per band: rises slowly, falls faster
                    for (i in 0 until BANDS) {
                        baseline[i] = if (e[i] > baseline[i]) {
                            baseline[i] * 0.98f + e[i] * 0.02f
                        } else {
                            baseline[i] * 0.9f + e[i] * 0.1f
                        }
                    }
                    prevPeak = p
                    prevHf2 = prevHf
                    prevHf = hf
                }
            } finally {
                try { aec?.release() } catch (ex: Exception) {}
                try { recorder.stop() } catch (ex: Exception) {}
                recorder.release()
            }
        }
    }

    override fun onDestroy() {
        active = false
        running = false
        paused = false
        learning = false
        level = 0f
        ClapTapService.instance?.releaseHold()
        worker?.join(500)
        super.onDestroy()
    }
}
