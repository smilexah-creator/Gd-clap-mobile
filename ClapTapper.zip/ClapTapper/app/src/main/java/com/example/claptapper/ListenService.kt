package com.example.claptapper

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.abs

/**
 * Foreground service that listens to the microphone and asks
 * ClapTapService to tap when a clap / loud sound is detected.
 *
 * Phone sound filter (pref "filter"):
 *   0 Off    - plain microphone, hears everything
 *   1 Smart  - echo cancellation + adaptive background level
 *   2 Strict - Smart, and detection pauses while the phone plays audio
 */
class ListenService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var level = 0f
        @Volatile var paused = false
        @Volatile var taps = 0
        @Volatile var tapEvent = 0L

        const val PREFS = "cfg"
        private const val CHANNEL = "listen"
        private const val ACTION_STOP = "com.example.claptapper.STOP"
        private const val ACTION_RELOAD = "com.example.claptapper.RELOAD"

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, ListenService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ListenService::class.java))
        }

        /** Re-create the recorder (needed when the filter option changes). */
        fun reload(ctx: Context) {
            if (running) {
                ctx.startService(Intent(ctx, ListenService::class.java).setAction(ACTION_RELOAD))
            }
        }
    }

    @Volatile private var active = false
    @Volatile private var restartRecorder = false
    private var worker: Thread? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_RELOAD -> {
                restartRecorder = true
                return START_NOT_STICKY
            }
        }
        startInForeground()
        if (!running) {
            running = true
            active = true
            taps = 0
            worker = Thread { listenLoop() }.also { it.start() }
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, ListenService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL)
            .setContentTitle("Clap Tapper is listening")
            .setContentText("A clap will tap the screen")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_media_pause),
                    "Stop", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun listenLoop() {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val am = getSystemService(AudioManager::class.java)
        val rate = 16000
        val frame = 512 // ~32 ms
        val buffer = ShortArray(frame)

        var lastTap = 0L
        var baseline = 0f
        var prevPeak = 0f
        var lastPhoneAudio = 0L
        var lastGateCheck = 0L

        while (active) {
            restartRecorder = false
            val filter = prefs.getInt("filter", 1)
            val source = if (filter == 0) {
                MediaRecorder.AudioSource.MIC
            } else {
                MediaRecorder.AudioSource.VOICE_COMMUNICATION
            }
            val minBuf = AudioRecord.getMinBufferSize(
                rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val recorder = try {
                AudioRecord(
                    source, rate, AudioFormat.CHANNEL_IN_MONO,
                    AudioFormat.ENCODING_PCM_16BIT, maxOf(minBuf, frame * 8)
                )
            } catch (e: Exception) {
                stopSelf(); return
            }
            if (recorder.state != AudioRecord.STATE_INITIALIZED) {
                recorder.release(); stopSelf(); return
            }

            var aec: AcousticEchoCanceler? = null
            if (filter != 0 && AcousticEchoCanceler.isAvailable()) {
                try {
                    aec = AcousticEchoCanceler.create(recorder.audioSessionId)
                    aec?.enabled = true
                } catch (e: Exception) {
                    aec = null
                }
            }

            recorder.startRecording()
            try {
                while (active && !restartRecorder) {
                    val n = recorder.read(buffer, 0, frame)
                    if (n <= 0) continue
                    var peakInt = 0
                    for (i in 0 until n) peakInt = maxOf(peakInt, abs(buffer[i].toInt()))
                    val p = peakInt / 32768f
                    level = p

                    val sens = prefs.getInt("sensitivity", 60)
                    val threshold = 0.5f - sens / 100f * 0.47f
                    val mode = prefs.getInt("mode", 0)
                    val cooldown = prefs.getInt("cooldown", 500)
                    val now = SystemClock.elapsedRealtime()

                    // Strict filter: stay quiet while the phone itself is playing sound
                    var gated = false
                    if (filter == 2) {
                        if (now - lastGateCheck > 150) {
                            lastGateCheck = now
                            val playing = am.isMusicActive ||
                                am.activePlaybackConfigurations.isNotEmpty()
                            if (playing) lastPhoneAudio = now
                        }
                        gated = now - lastPhoneAudio < 700
                    }
                    paused = gated

                    // A clap is a sharp onset; steady sound (music, speech) is not.
                    val sharpOnset = p > prevPeak * 2.2f + 0.01f
                    var trigger = p > threshold
                    if (trigger && mode == 0) trigger = sharpOnset
                    if (trigger && filter != 0) {
                        // must clearly stand out from the current background level
                        trigger = p > baseline * (if (mode == 0) 3f else 1.8f)
                    }

                    if (trigger && !gated && now - lastTap > cooldown) {
                        lastTap = now
                        ClapTapService.instance?.tapPercent(
                            prefs.getInt("x", 50), prefs.getInt("y", 50)
                        )
                        taps++
                        tapEvent = now
                    }

                    // Background level: rises slowly, falls faster
                    baseline = if (p > baseline) {
                        baseline * 0.98f + p * 0.02f
                    } else {
                        baseline * 0.9f + p * 0.1f
                    }
                    prevPeak = p
                }
            } finally {
                try { aec?.release() } catch (e: Exception) {}
                try { recorder.stop() } catch (e: Exception) {}
                recorder.release()
            }
        }
    }

    override fun onDestroy() {
        active = false
        running = false
        paused = false
        level = 0f
        worker?.join(500)
        super.onDestroy()
    }
}
