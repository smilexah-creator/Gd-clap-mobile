package com.example.claptapper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.max

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var orb: OrbView
    private lateinit var statusTitle: TextView
    private lateinit var statusSub: TextView
    private lateinit var setupCard: LinearLayout
    private lateinit var micRow: SetupRow
    private lateinit var accRow: SetupRow
    private lateinit var meter: MeterView
    private lateinit var picker: PhonePickerView
    private lateinit var coords: TextView
    private lateinit var modeHint: TextView
    private lateinit var filterHint: TextView
    private lateinit var learnBtn: TextView

    private var shownLevel = 0f
    private var lastTapEvent = 0L

    private val ticker = object : Runnable {
        override fun run() {
            tick()
            handler.postDelayed(this, 40)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(ListenService.PREFS, MODE_PRIVATE)
        window.statusBarColor = C.BG
        window.navigationBarColor = C.BG
        buildUi()
    }

    override fun onResume() {
        super.onResume()
        refreshSetup()
        handler.post(ticker)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
    }

    // ---------------------------------------------------------------- UI

    private fun lp(top: Int = 0, bottom: Int = 0) =
        LinearLayout.LayoutParams(MATCH, WRAP).apply {
            topMargin = dp(top)
            bottomMargin = dp(bottom)
        }

    private fun card(title: String? = null): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        background = shape(C.CARD, 20f, C.STROKE, 1)
        setPadding(dp(18), dp(16), dp(18), dp(18))
        if (title != null) {
            val t = label(title.uppercase(), 11f, C.MUTED, true)
            t.letterSpacing = 0.12f
            addView(t, lp(0, 10))
        }
    }

    private fun thresholdFor(sensitivity: Int): Float = 0.5f - sensitivity / 100f * 0.47f

    private fun buildUi() {
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(C.BG)
        scroll.isVerticalScrollBarEnabled = false
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(18), dp(28), dp(18), dp(32))
        scroll.addView(root)
        setContentView(scroll)

        // Header
        val title = label("Clap Tapper", 30f, C.TEXT, true)
        title.letterSpacing = -0.02f
        root.addView(title)
        root.addView(label("Clap, and your phone taps for you.", 14f, C.MUTED), lp(2))

        // Hero
        val hero = card()
        orb = OrbView(this)
        orb.setOnClickListener { onOrbClick() }
        hero.addView(orb, LinearLayout.LayoutParams(MATCH, dp(220)))
        statusTitle = label("", 22f, C.TEXT, true)
        statusTitle.gravity = Gravity.CENTER
        statusSub = label("", 13f, C.MUTED)
        statusSub.gravity = Gravity.CENTER
        hero.addView(statusTitle, lp(0))
        hero.addView(statusSub, lp(4))
        root.addView(hero, lp(20))

        // Setup
        setupCard = card("Setup")
        micRow = SetupRow(this, "Microphone", "Needed to hear claps", "Allow") { requestPerms() }
        accRow = SetupRow(this, "Tap service", "Lets the app tap the screen", "Enable") { openAccessibility() }
        setupCard.addView(micRow)
        setupCard.addView(accRow)
        root.addView(setupCard, lp(14))

        // Listening
        val det = card("Listening")
        meter = MeterView(this)
        meter.threshold = thresholdFor(prefs.getInt("sensitivity", 60))
        det.addView(meter, LinearLayout.LayoutParams(MATCH, dp(28)))
        det.addView(
            sliderRow("Sensitivity", "sensitivity", 0, 100, 60, { "$it%" }) {
                meter.threshold = thresholdFor(it)
            },
            lp(10)
        )
        val modeSeg = Segmented(this, listOf("Claps", "Any loud noise"), prefs.getInt("mode", 0)) {
            prefs.edit().putInt("mode", it).apply()
            modeHint.text = modeText(it)
        }
        det.addView(modeSeg, lp(16))
        modeHint = label(modeText(prefs.getInt("mode", 0)), 12f, C.MUTED)
        det.addView(modeHint, lp(8))
        root.addView(det, lp(14))

        // Phone sound filter
        val flt = card("Ignore phone sounds")
        val fltSeg = Segmented(this, listOf("Off", "Smart", "Strict"), prefs.getInt("filter", 1)) {
            prefs.edit().putInt("filter", it).apply()
            filterHint.text = filterText(it)
            ListenService.reload(this)
        }
        flt.addView(fltSeg)
        filterHint = label(filterText(prefs.getInt("filter", 1)), 12f, C.MUTED)
        flt.addView(filterHint, lp(8))
        learnBtn = label("", 14f, C.TEXT, true)
        learnBtn.gravity = Gravity.CENTER
        learnBtn.background = shape(C.CARD2, 12f, C.STROKE2, 1)
        learnBtn.setPadding(dp(8), dp(12), dp(8), dp(12))
        learnBtn.setOnClickListener { learnTapped() }
        flt.addView(learnBtn, lp(14))
        flt.addView(
            label("Playing a game? Tap this, switch to the game and let its music play for 12 seconds. Don't clap during that time. Your phone buzzes when it's done.", 12f, C.MUTED),
            lp(8)
        )
        flt.addView(
            label("Tip: with headphones on, your phone's sound can't reach the mic at all.", 12f, C.MUTED),
            lp(8)
        )
        root.addView(flt, lp(14))

        // Tap target
        val tgt = card("Tap target")
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        picker = PhonePickerView(this)
        picker.xPct = prefs.getInt("x", 50)
        picker.yPct = prefs.getInt("y", 50)
        picker.onPick = { x, y ->
            prefs.edit().putInt("x", x).putInt("y", y).apply()
            updateCoords()
        }
        row.addView(picker, LinearLayout.LayoutParams(dp(110), WRAP))

        val right = LinearLayout(this)
        right.orientation = LinearLayout.VERTICAL
        right.addView(label("Drag on the phone to choose where the tap lands.", 13f, C.MUTED))
        coords = label("", 20f, C.TEXT, true)
        right.addView(coords, lp(14))
        val test = label("Test tap in 3 s", 14f, C.TEXT, true)
        test.gravity = Gravity.CENTER
        test.background = shape(C.CARD2, 12f, C.STROKE2, 1)
        test.setPadding(0, dp(12), 0, dp(12))
        test.setOnClickListener { testTap() }
        right.addView(test, lp(16))
        val rightLp = LinearLayout.LayoutParams(0, WRAP, 1f)
        rightLp.leftMargin = dp(16)
        row.addView(right, rightLp)
        tgt.addView(row)
        val styleSeg = Segmented(this, listOf("Tap", "Hold on screen"), prefs.getInt("tap_style", 0)) {
            prefs.edit().putInt("tap_style", it).apply()
            if (it == 0) ClapTapService.instance?.releaseHold()
        }
        tgt.addView(styleSeg, lp(16))
        tgt.addView(
            label("Hold on screen: a clap presses and keeps your finger down, the next clap lets go.", 12f, C.MUTED),
            lp(8)
        )
        tgt.addView(
            sliderRow("Pause between taps", "cooldown_ms", 0, 3000, 0, { if (it == 0) "0 (instant)" else "%.1f s".format(it / 1000f) }),
            lp(18)
        )
        root.addView(tgt, lp(14))
        updateCoords()

        root.addView(
            label("Keep the notification showing - Android needs it to let the app use the microphone in the background.", 12f, C.MUTED),
            lp(18)
        )
    }

    private fun modeText(mode: Int) = if (mode == 0) {
        "Reacts to sharp sounds like claps, snaps and knocks. Ignores steady noise."
    } else {
        "Reacts to any sound above the white line, including speech."
    }

    private fun filterText(f: Int) = when (f) {
        0 -> "Hears everything, including your phone's own speaker."
        1 -> "Analyses the sound's frequencies. A clap must stand out from the background and the learned game music in several frequency bands at once."
        else -> "Smart, and also pauses listening while the phone plays any audio."
    }

    private fun sliderRow(
        title: String, key: String, lo: Int, hi: Int, def: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit = {}
    ): LinearLayout {
        val value = prefs.getInt(key, def)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        val valueText = label(fmt(value), 14f, C.ACC1, true)
        head.addView(label(title, 14f, C.TEXT, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(valueText)
        box.addView(head)

        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = value - lo
        bar.progressTintList = ColorStateList.valueOf(C.ACC1)
        bar.thumbTintList = ColorStateList.valueOf(Color.WHITE)
        bar.progressBackgroundTintList = ColorStateList.valueOf(C.CARD2)
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val actual = p + lo
                prefs.edit().putInt(key, actual).apply()
                valueText.text = fmt(actual)
                onChange(actual)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(bar, lp(6))
        return box
    }

    private fun updateCoords() {
        coords.text = "X ${picker.xPct}% · Y ${picker.yPct}%"
    }

    // ------------------------------------------------------------ Actions

    private fun hasMic() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private fun hasTapService() = ClapTapService.instance != null

    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refreshSetup()
    }

    private fun openAccessibility() {
        Toast.makeText(this, "Find Clap Tapper in the list and turn it on", Toast.LENGTH_LONG).show()
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun onOrbClick() {
        when {
            !hasMic() -> requestPerms()
            !hasTapService() -> openAccessibility()
            ListenService.running -> ListenService.stop(this)
            else -> ListenService.start(this)
        }
    }

    private fun learnTapped() {
        if (!ListenService.running) {
            Toast.makeText(this, "Start listening first (tap the power button)", Toast.LENGTH_SHORT).show()
            return
        }
        if (ListenService.learning) return
        ListenService.learn(this)
        Toast.makeText(this, "Learning for 12 s - open your game now", Toast.LENGTH_LONG).show()
    }

    private fun testTap() {
        if (!hasTapService()) {
            Toast.makeText(this, "Enable the tap service first", Toast.LENGTH_SHORT).show()
            return
        }
        Toast.makeText(this, "Tapping in 3 seconds...", Toast.LENGTH_SHORT).show()
        handler.postDelayed({
            ClapTapService.instance?.tapPercent(prefs.getInt("x", 50), prefs.getInt("y", 50))
            picker.pulse()
        }, 3000)
    }

    // --------------------------------------------------------------- Live

    private fun refreshSetup() {
        val mic = hasMic()
        val acc = hasTapService()
        micRow.setDone(mic)
        accRow.setDone(acc)
        setupCard.visibility = if (mic && acc) android.view.View.GONE else android.view.View.VISIBLE
    }

    private fun tick() {
        val running = ListenService.running
        val target = if (running) ListenService.level else 0f
        shownLevel = max(target, shownLevel * 0.82f)

        orb.on = running
        orb.level = shownLevel
        orb.invalidate()
        meter.level = shownLevel
        meter.invalidate()

        if (ListenService.tapEvent != lastTapEvent) {
            lastTapEvent = ListenService.tapEvent
            orb.flash()
            picker.pulse()
        }

        val learnText = when {
            ListenService.learning -> "Learning... ${ListenService.learnLeft} s left"
            prefs.contains("profile") -> "Re-learn game sound  ✓"
            else -> "Learn game sound"
        }
        if (learnBtn.text.toString() != learnText) learnBtn.text = learnText

        val mic = hasMic()
        val acc = hasTapService()
        val title: String
        val sub: String
        when {
            !mic || !acc -> {
                title = "Finish setup"
                sub = "Complete the steps below to get started"
            }
            !running -> {
                title = "Tap to start"
                sub = "Your phone is not listening"
            }
            ListenService.learning -> {
                title = "Learning"
                sub = "Keep the game music playing - don't clap"
            }
            ListenService.paused -> {
                title = "Paused"
                sub = "Phone is playing sound (Strict filter)"
            }
            else -> {
                title = "Listening"
                val n = ListenService.taps
                sub = if (n == 0) "Clap to tap the screen" else if (n == 1) "1 tap this session" else "$n taps this session"
            }
        }
        if (statusTitle.text.toString() != title) statusTitle.text = title
        if (statusSub.text.toString() != sub) statusSub.text = sub
    }
}
