package com.example.claptapper

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var status: TextView
    private lateinit var toggle: Button

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences(ListenService.PREFS, MODE_PRIVATE)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Clap Tapper"
            textSize = 28f
            gravity = Gravity.CENTER
        })

        status = TextView(this).apply {
            textSize = 15f
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(status)

        root.addView(button("1. Allow microphone") { requestPerms() })
        root.addView(button("2. Enable tap service (Accessibility)") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })

        root.addView(label("Settings"))
        addSlider(root, "Sensitivity (higher = quieter sounds trigger)", "sensitivity", 100, 60)
        addSlider(root, "Tap position X (%)", "x", 100, 50)
        addSlider(root, "Tap position Y (%)", "y", 100, 50)
        addSlider(root, "Delay between taps (ms)", "cooldown", 3000, 500)

        root.addView(button("Test tap in 3 seconds") {
            status.postDelayed({
                ClapTapService.instance?.tapPercent(prefs.getInt("x", 50), prefs.getInt("y", 50))
            }, 3000)
        })

        toggle = button("") { toggleListening() }
        root.addView(toggle)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        val mic = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val acc = ClapTapService.instance != null
        status.text = "Microphone: ${if (mic) "OK" else "not allowed"}\n" +
            "Tap service: ${if (acc) "OK" else "not enabled"}\n" +
            "Listening: ${if (ListenService.running) "ON" else "OFF"}"
        toggle.text = if (ListenService.running) "Stop listening" else "Start listening"
    }

    private fun requestPerms() {
        val perms = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(perms.toTypedArray(), 1)
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        refresh()
    }

    private fun toggleListening() {
        val intent = Intent(this, ListenService::class.java)
        if (ListenService.running) {
            stopService(intent)
        } else {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                requestPerms(); return
            }
            startForegroundService(intent)
        }
        toggle.postDelayed({ refresh() }, 400)
    }

    private fun button(text: String, onClick: () -> Unit) = Button(this).apply {
        this.text = text
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 18f
        setPadding(0, dp(20), 0, dp(4))
    }

    private fun addSlider(root: LinearLayout, title: String, key: String, max: Int, def: Int) {
        val value = prefs.getInt(key, def)
        val tv = TextView(this).apply { text = "$title: $value" }
        val bar = SeekBar(this).apply {
            this.max = max
            progress = value
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    prefs.edit().putInt(key, p).apply()
                    tv.text = "$title: $p"
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        root.addView(tv)
        root.addView(bar)
    }
}
